$DIR = "*.exe"
$count=1
foreach ($file in get-ChildItem $DIR)
{
	add-content $file `0
	$name=[string]$count + ".exe"
	Rename-Item -path $file -newName $name
	$count = $count + 1
}